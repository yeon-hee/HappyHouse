<template>
    <div  class="clearAllContainer">
        <!--<span class="clearAllBtn" @click="clearTodo">Clear All</span>-->
        <span class="clearAllBtn" @click="backToIndex">로비로 이동</span>
    </div>
</template>

<script>
    //import Constant from '../Constant';

    export default {
        methods: {
            // clearTodo() {
            //     this.$store.dispatch(Constant.CLEAR_TODO);
            // }
            backToIndex() {
                //여기 수정. 인덱스.jsp로 분기
                 window.open("http://127.0.0.1:7070/myapp/index.jsp", "_blank");             
            }
        },
    }
</script>

<style scoped>
.clearAllContainer {
    width: 8.5rem;
    height: 50px;
    line-height: 50px;
    background-color: white;
    border-radius: 5px;
    margin: 0 auto;
  }
  .clearAllBtn {
    color: #e20303;
      /* 추가 */
      display: block;
  }
</style>