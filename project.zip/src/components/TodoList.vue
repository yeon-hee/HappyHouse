<!-- <template>
  <div>
    <ul>
      <li v-for="(todoItem) in todolist" v-bind:key="todoItem.no" class="shadow" 
      @click="getTodo(todoItem.no)" :class="{done: todoItem.done=='Y'}">
        <i class="checkBtn fas fa-check" @click.stop="completeTodo(todoItem.no)" v-show="todoItem.done =='N'"></i>
        {{todoItem.content}} : {{todoItem.endDate}}
        <span
          class="removeBtn"
          type="button"
          @click.stop="removeTodo(todoItem.no)"
        >
          <i class="far fa-trash-alt"></i>
        </span>
      </li>
    </ul>
  </div>
</template> -->
<template>
  <div>
    <ul>
      <!-- store의 action을 mapActions헬퍼를 통해 연결한 경우는 매개변수를 action에 맞춰서 전달해야함.payload형식 -->
      <li v-for="(todoItem) in todolist" v-bind:key="todoItem.qna_no" class="shadow" 
      @click="getTodo(todoItem.qna_no)" >
        <i class="checkBtn fas fa-check" @click.stop="completeTodo({qna_no :todoItem.qna_no})" ></i>
        {{todoItem.qna_title}} : {{todoItem.qna_content}}
        <span
          class="removeBtn"
          type="button"
          @click.stop="removeTodo({qna_no:todoItem.qna_no})"
        >
          <i class="far fa-trash-alt"></i>
        </span>
      </li>
    </ul>
  </div>
</template>

<script>
import Constant from '../Constant';
import { mapActions } from 'vuex'

export default {
  computed: {
    todolist() {
      return this.$store.state.todoItems; 
    }
  },
  created () {
    this.$store.dispatch(Constant.GET_TODOLIST);
  },
/*   methods: {
    getTodo(no) {
      console.log('getTodo : '+no);
      this.$store.dispatch(Constant.GET_TODO,{no});
    },
    removeTodo(no){
      console.log('removeTodo : '+no);
      this.$store.dispatch(Constant.REMOVE_TODO,{no});
    },
    completeTodo(no){
      console.log('completeTodo : '+no);
      this.$store.dispatch(Constant.COMPLETE_TODO,{no});
    }
  }, */

  methods: {
    getTodo(no) {
      console.log('getTodo :::: '+no);
      this.$router.push('/detail/'+no);
    },
    ...mapActions([
      Constant.REMOVE_TODO,Constant.COMPLETE_TODO
    ])
  },

};
</script>

<style scoped>
ul {
  list-style-type: none;
  padding-left: 0px;
  margin-top: 0;
  text-align: left;
}
li {
  display: flex;
  min-height: 50px;
  height: 50px;
  line-height: 50px;
  margin: 0.5rem 0;
  padding: 0 0.9rem;
  background: white;
  border-radius: 5px;
}
.checkBtn {
  line-height: 45px;
  color: #62acde;
  margin-right: 5px;
}
.removeBtn {
  margin-left: auto;
  color: #de4343;
}

.list-item {
  display: inline-block;
  margin-right: 10px;
}
.list-move {
  transition: transform 1s;
}
.list-enter-active,
.list-leave-active {
  transition: all 1s;
}
.list-enter,
.list-leave-to {
  opacity: 0;
  transform: translateY(30px);
}
.done{
  background-color: lightslategray;
}
</style>