<template>
<!--
    <div class="inputBox shadow">
    할일입력 : <input type="text" v-model="todo.content" placeholder="할일 입력" >
        기한 : <input type="date" v-model="todo.endDate" placeholder="기한">
        <span class="addContainer" @click="addTodo">
            <div class="addBtn fas fa-plus" aria-hidden='true'></div>
        </span>
    </div>
-->
    <div>
    <table>
      <tbody>
        <tr>
          <td>제목</td>
          <td>
            <input type="text" v-model="todo.qna_title" />
          </td>
        </tr>
        <tr>
          <td>내용</td>
          <td>
            <textarea  v-model="todo.qna_content" />
          </td>
        </tr>
        <tr>
          <td>ID</td>
          <td>
            <textarea  v-model="todo.qna_userid" />
          </td>
        </tr>
        <tr>
          <td colspan="2">
            <span class="addContainer" @click="addTodo">
              <div class="addBtn fas fa-plus" aria-hidden="true"></div>
            </span>
          </td>
        </tr>
      </tbody>
    </table>
    </div>


</template>

<script>
import Constant from '../Constant';
export default {
    data() {
        return {
            todo : {
                qna_title: '',
                qna_content: '',
                qna_datetime:'',
                //qna_no: '',
                qna_userid: ''
            }
        }
    },
    methods: {

        addTodo(){

            if(this.todo.qna_title.trim() != ''){
                console.log('할일 추가 :: ');
                console.log(this.todo);
                this.$store.dispatch(Constant.ADD_TODO,{qna_content : this.qna_content,
               qna_title:this.qna_title,
               qna_userid: this.qna_userid
                });
                this.$router.push('/list');
                //this.$router.push('/');
            }else{
                console.log('공백입력.');
            }    
            this.clear();
        },
        clear(){
            this.todo = {
            };  //this.todo = {} 이렇게 하면 안나옴
        }
    }
}     
</script>

<style scoped>
input:focus {
  outline: none;
}
.inputBox {
  background: white;
  height: 50px;
  line-height: 50px;
  border-radius: 5px;
}
.inputBox input {
  border-style: none;
  font-size: 0.9rem;
}

.addContainer{
  background: linear-gradient(to right, #647811, #527810);
  display: inline-block;
  width: 3rem;
  border-radius: 5px 5px 5px 5px;
}
.modifyBtn, .addBtn {
  color: white;
  vertical-align: middle;
}

table {
  margin: 10px auto;
  border-collapse: collapse;
  border: 2px solid #996;
  font: normal 90%/140% verdana, arial, helvetica, sans-serif;
  color: #333;
  background: #fffff0;
}

.caption {
  background-color: #222;
  vertical-align: middle;
  text-align: center;
  padding: 15px;
  font-size: 20px;
  color: #fff;
}

td,
th {
  border: 1px solid #cc9;
  padding: 0.3em;
}
thead th,
tfoot th {
  bgcolor: "#f5deb3";
  border: 1px solid #cc9;
  text-align: center;
  font-size: 1em;
  font-weight: bold;
  color: #444;
  background: #dbd9c0;
}
tbody td a {
  background: transparent;
  color: #72724c;
  text-decoration: none;
  border-bottom: 1px dotted #cc9;
}
tbody td a:hover {
  background: transparent;
  color: #666;
  border-bottom: 1px dotted #72724c;
}
tbody th a {
  background: transparent;
  color: #72724c;
  text-decoration: none;
  font-weight: bold;
  border-bottom: 1px dotted #cc9;
}
tbody th a:hover {
  background: transparent;
  color: #666;
  border-bottom: 1px dotted #72724c;
}
tbody th,
tbody td {
  vertical-align: top;
  text-align: center;
}
tfoot td {
  border: 1px solid #996;
}
.odd {
  color: #333;
  background: #f7f5dc;
}
tbody tr:hover {
  color: #333;
  background: #fff;
}
tbody tr:hover th,
tbody tr.odd:hover th {
  color: #333;
  background: #ddd59b;
}

tbody tr {
  height: 50px;
  line-height: 50px;
}
ul {
  padding: 22px 50px 50px 490px;
  width: 940px;
  list-style: none;
}
#gnb li {
  display: inline;
}
#gnb li a {
  display: inline-block;
  background: #222;
  color: #fff;
  width: 150px;
  height: 23px;
  padding-top: 3px;
  text-align: center;
}
#gnb li a:hover {
  background: #900;
}
</style>