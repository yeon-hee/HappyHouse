<template>
  <header>
    <img alt="Vue logo" src="../assets/qna.png" />
    <h1>Q&A 게시판</h1>
    <div>
      <router-link to="/input">Q&A 추가</router-link> &nbsp;
      <router-link to="/list">Q&A 목록</router-link>
    </div>
  </header>
</template>

<script>
export default {};
</script>

<style scoped>
h1 {
  color: #2f3b52;
  font-weight: 900;
  margin: 2.5rem 0 1.5rem;
}
</style>