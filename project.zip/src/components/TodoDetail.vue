<template>
  <div>
    <table>
      <tbody>
        <tr>
          <td>번호</td>
          <td>
            <input type="text" v-model="todo.qna_no" readonly />
          </td>
        </tr>
        <tr>
          <td>ID</td>
          <td>
            <input type="text" v-model="todo.qna_userid" />
          </td>
        </tr>
        <tr>
          <td>제목</td>
          <td>
            <input type="text" v-model="todo.qna_title" />
          </td>
        </tr>
         <tr>
          <td>내용</td>
          <td>
            <input type="text" v-model="todo.qna_content" />
          </td>
        </tr>
        <tr>
          <td>등록일</td>
          <td>
            <input type="text" v-model="todo.qna_datetime" readonly />
          </td>
        </tr>
        <!-- <tr>
          <td>기한</td>
          <td>
            <input type="date" v-model="todo.endDate" />
          </td>
        </tr>
        <tr>
          <td>완료여부</td>
          <td>
            <span v-if="todo.done=='Y'">완료</span>
            <span v-else>미완료</span>
          </td>
        </tr> -->
        <tr>
          <td colspan="2">
            <span class="addContainer" @click="modifyTodo">
              <div class="modifyBtn fas fa-pen-square" aria-hidden="true"></div>
            </span>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
import Constant from "../Constant";
export default {
  created() {
    this.getTodo(this.$route.params.qna_no);
  },
  computed: {
    todo: {
      get() {
        // 화살표함수 사용하면 안됨. this : undefined 로 나옴.
        console.log("TodoInput computed get");
        return this.$store.state.todo;
      },
      set(newTodo) {
        console.log("TodoInput computed set...");
        this.todo.qna_no = newTodo.qna_no;
        this.todo.qna_title = newTodo.qna_title;
        this.todo.qna_content = newTodo.qna_content;
        this.todo.qna_userid = newTodo.qna_userid;
        this.todo.qna_datetime = newTodo.qna_datetime;
      }
    }
  },
  methods: {
    getTodo(no) {
      console.log("getTodo : " + no);
      this.$store.dispatch(Constant.GET_TODO, { no });
    },
    modifyTodo() {
      if (this.todo.content.trim() != "") {
        console.log("할일 수정:: ");
        console.log(this.todo);
        this.$store.dispatch(Constant.MODIFY_TODO, { todo: this.todo });
        this.$router.push("/");
      } else {
        console.log("공백입력.");
      }
      this.clear();
    },
    clear() {
      this.todo = {}; 
    }
  }
}
</script>

<style scoped>
input:focus {
  outline: none;
}
.inputBox {
  background: white;
  height: 50px;
  line-height: 50px;
  border-radius: 5px;
}
.inputBox input {
  border-style: none;
  font-size: 0.9rem;
}
.addContainer {
  background: linear-gradient(to right, #6478fb, #8763fb);
  display: inline-block;
  width: 3rem;
  border-radius: 0 5px 5px 0;
}

.modifyBtn {
  color: white;
  vertical-align: middle;
}

table {
  margin: 10px auto;
  border-collapse: collapse;
  border: 2px solid #996;
  font: normal 90%/140% verdana, arial, helvetica, sans-serif;
  color: #333;
  background: #fffff0;
}

.caption {
  background-color: #222;
  vertical-align: middle;
  text-align: center;
  padding: 15px;
  font-size: 20px;
  color: #fff;
}

td,
th {
  border: 1px solid #cc9;
  padding: 0.3em;
}
thead th,
tfoot th {
  bgcolor: "#f5deb3";
  border: 1px solid #cc9;
  text-align: center;
  font-size: 1em;
  font-weight: bold;
  color: #444;
  background: #dbd9c0;
}
tbody td a {
  background: transparent;
  color: #72724c;
  text-decoration: none;
  border-bottom: 1px dotted #cc9;
}
tbody td a:hover {
  background: transparent;
  color: #666;
  border-bottom: 1px dotted #72724c;
}
tbody th a {
  background: transparent;
  color: #72724c;
  text-decoration: none;
  font-weight: bold;
  border-bottom: 1px dotted #cc9;
}
tbody th a:hover {
  background: transparent;
  color: #666;
  border-bottom: 1px dotted #72724c;
}
tbody th,
tbody td {
  vertical-align: top;
  text-align: center;
}
tfoot td {
  border: 1px solid #996;
}
.odd {
  color: #333;
  background: #f7f5dc;
}
tbody tr:hover {
  color: #333;
  background: #fff;
}
tbody tr:hover th,
tbody tr.odd:hover th {
  color: #333;
  background: #ddd59b;
}

tbody tr {
  height: 50px;
  line-height: 50px;
}
ul {
  padding: 22px 50px 50px 490px;
  width: 940px;
  list-style: none;
}
#gnb li {
  display: inline;
}
#gnb li a {
  display: inline-block;
  background: #222;
  color: #fff;
  width: 150px;
  height: 23px;
  padding-top: 3px;
  text-align: center;
}
#gnb li a:hover {
  background: #900;
}
</style>