import Vue from 'vue';
import Vuex from 'vuex';
import Constant from './Constant.js';
import http from './http-common.js';
Vue.use(Vuex);
const store = new Vuex.Store({
    state: {
        todoItems: [],
        todo: {}
    },
    actions: { // 외부와의 통신을 통해 데이터 처리 dispath에 의해 호출됨.

        /*         'getTodoList': function(store) {
                    http.get('/todolist/user/' + 'java')
                        .then(response => store.commit(Constant.GET_TODOLIST, { todoItems: response.data }))
                        .catch(exp => alert('getTodoList처리에 실패하였습니다.' + exp));
                }, */
        [Constant.GET_TODOLIST]: store => {
            http.get('/api/qna')
                .then(response => store.commit(Constant.GET_TODOLIST, { todoItems: response.data }))
                .catch(exp => alert('getTodoList처리에 실패하였습니다.' + exp));
        },
        [Constant.GET_TODO]: (store, payload) => {
            http.get('/api/qna/' + payload.qna_no)
                .then(response => store.commit(Constant.GET_TODO, { todo: response.data }))
                .catch(exp => alert('getTodo처리에 실패하였습니다.' + exp));

        },
        [Constant.ADD_TODO]: (store, payload) => {
            http.post('/api/qna/', {
                    qna_content : payload.qna_content,
                    qna_title : payload.qna_title,
                    qna_userid  : payload.qna_userid
                })
                .then(() => {
                    console.log('추가하였습니다.');
                    store.dispatch(Constant.GET_TODOLIST);
                })
                .catch(exp => alert('추가 처리에 실패하였습니다.' + exp));
        },
        [Constant.MODIFY_TODO]: (store, payload) => {
            http.put('/api/qna/' + payload.todo.qna_no, {
                qna_no: payload.todo.qna_no,
                qna_content: payload.todo.qna_content,
                qna_title: payload.todo.qna_title,
                qna_userid: payload.todo.qna_userid,
                qna_datetime : payload.todo.qna_datetime
                })
                .then(() => {
                    console.log('수정하였습니다.');
                    store.dispatch(Constant.GET_TODOLIST);
                })
                .catch(exp => alert('수정 처리에 실패하였습니다.' + exp));
        },
        [Constant.REMOVE_TODO]: (store, payload) => {
            http.delete('/api/qna/' + payload.qna_no)
                .then(() => {
                    console.log('삭제하였습니다.');
                    store.dispatch(Constant.GET_TODOLIST);
                })
                .catch(exp => alert('삭제 처리에 실패하였습니다.' + exp));

        },
        // [Constant.COMPLETE_TODO]: (store, payload) => {
        //     http.put('/api/qna/' + payload.qna_no)
        //         .then(() => {
        //             console.log('완료 처리하였습니다.');
        //             store.dispatch(Constant.GET_TODOLIST);
        //         })
        //         .catch(exp => alert('완료 처리에 실패하였습니다.' + exp));
        // },
        // [Constant.CLEAR_TODO]: (store) => {
        //     http.delete('/api/qna/' + 'java')
        //         .then(() => {
        //             console.log('할일 목록을 삭제 처리하였습니다.');
        //             store.commit(Constant.CLEAR_TODO, { todoItems: [], todo: {} });
        //         })
        //         .catch(exp => alert('할일 목록을 삭제 처리에 실패하였습니다.' + exp));
        // },
    },
    mutations: { // 저장소에 데이터 실제 반영(commit시 호출됨)
        [Constant.GET_TODOLIST]: (state, payload) => {
            state.todoItems = payload.todoItems;
        },
        [Constant.GET_TODO]: (state, payload) => {
            state.todo = payload.todo;
        },
        [Constant.CLEAR_TODO]: (state, payload) => {
            state.todo = payload.todo;
            state.todoItems = payload.todoItems;
        }
    }
});


export default store;