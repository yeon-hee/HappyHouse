<template>
  <div id="app">
    <todo-header></todo-header>
    <router-view></router-view>
    <todo-footer></todo-footer>
  </div>
</template>

<script>

import Vue from 'vue';
import VueRouter from 'vue-router';
import TodoHeader from './components/TodoHeader.vue';
import TodoInput from './components/TodoInput.vue';
import TodoFooter from './components/TodoFooter.vue';
import TodoList from './components/TodoList.vue';
import TodoDetail from './components/TodoDetail.vue';

Vue.use(VueRouter);

const router = new VueRouter({
  mode : 'history',
  routes : [
    {path:'/',component:TodoList},
    {path:'/list',component:TodoList},
    {path:'/input',component:TodoInput},
    {path:'/detail/:no',component:TodoDetail}
  ]
});

export default {
  name: 'app',
  components: {
    TodoHeader,TodoFooter
  },
  router,
  data() {
    return {
      todoItems: [],
      todo : {}
    }
  },
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
body {
    text-align: center;
    background-color: #F6F6F8;
  }
  input {
    border-style: groove;
    width: 200px;
  }
  button {
    border-style: groove;
  }
  .shadow {
    box-shadow: 5px 10px 10px rgba(0, 0, 0, 0.03)
  }

</style>
